<?php
	// Enter your name or company name below
	$receiver_name = "Integres";
	
	// Enter your message subject below
	$receiver_subject = "Contato Site";
	
	// The main email address for receiving the form message
	$receiver_email = "atendimento@integres.com.br";
	
	// If you want to store all form data in a CSV file 
	// Change the generateCSV option from (false) to (true)
	$generateCSV = false;	
	
	// Name for generated CSV file 
	// Please don't change this name unless you have to
	$csvFileName = "formcsv.csv";
	
	// If you want to automatically reply to the sender 
	// Change the autoresponder option below from (false) to (true)
	$autoResponder = true;
?>






